<?php

namespace Modules\MockTestModule\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Concerns\HasUuids;

class MockTestModule extends Model
{
    use HasUuids;

    protected $table = 'mock_test_modules';

    protected $fillable = [
        'title',
        'description',
        'content',
        'status',
        'created_by',
    ];

    protected function casts(): array
    {
        return [
            'created_at' => 'datetime',
            'updated_at' => 'datetime',
        ];
    }
}
