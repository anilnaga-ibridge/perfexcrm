<template>
  <div class="edit-page space-y-6">
    <!-- Action Bar -->
    <div class="page-header flex justify-between items-center">
      <div>
        <h1 class="page-title text-xl font-bold text-slate-800">Edit Mock Test Module</h1>
        <p class="text-xs text-slate-500 mt-0.5">Modify properties and configurations of this entry</p>
      </div>
      <div>
        <a-button @click="goBack" class="btn-outline">
          Back to List
        </a-button>
      </div>
    </div>

    <!-- Edit Form Card -->
    <div class="bg-white border border-slate-200 rounded-lg shadow-sm p-6 max-w-3xl" v-if="item">
      <Form
        :initial="item"
        submit-label="Update Entry"
        :busy="saving"
        :errors="errors"
        @submit="handleSubmit"
        @cancel="goBack"
      />
    </div>

    <!-- Loading State -->
    <div class="bg-white border border-slate-200 rounded-lg shadow-sm p-12 text-center" v-else-if="loading">
      <a-spin size="large" tip="Loading data..." />
    </div>

    <!-- Error State -->
    <div class="bg-white border border-slate-200 rounded-lg shadow-sm p-12 text-center text-slate-400" v-else>
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" width="48" height="48" class="mx-auto mb-2 text-rose-500"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
      <p class="text-sm font-semibold text-slate-700">Entry Not Found</p>
      <p class="text-xs text-slate-400 mt-1">The requested entry does not exist or has been deleted.</p>
    </div>
  </div>
</template>

<script>
import { ref, reactive, onMounted } from 'vue';
import { useRouter, useRoute } from 'vue-router';
import axios from 'axios';
import { message } from 'ant-design-vue';
import Form from '../../components/Form.vue';

export default {
  name: 'MockTestModuleEdit',
  components: { Form },
  setup() {
    const router = useRouter();
    const route = useRoute();
    const item = ref(null);
    const loading = ref(true);
    const saving = ref(false);
    const errors = reactive({});
    const moduleSlug = route.params.slug;
    const itemId = route.query.id;

    onMounted(async () => {
      if (!itemId) {
        loading.value = false;
        return;
      }
      try {
        const { data } = await axios.get(`/api/mock-test-module/${itemId}`);
        item.value = data.data;
      } catch (e) {
        console.error('Failed to load:', e);
      } finally {
        loading.value = false;
      }
    });

    const handleSubmit = async (form) => {
      saving.value = true;
      Object.keys(errors).forEach(k => delete errors[k]);
      try {
        await axios.put(`/api/mock-test-module/${itemId}`, { ...form });
        message.success('Updated successfully.');
        router.push(`/admin/module/${moduleSlug}/mock-test-modules`);
      } catch (e) {
        const resp = e.response?.data;
        if (resp?.errors) {
          Object.assign(errors, resp.errors);
        }
        message.error(resp?.message || 'Failed to update.');
      } finally {
        saving.value = false;
      }
    };

    const goBack = () => {
      router.push(`/admin/module/${moduleSlug}/mock-test-modules`);
    };

    return { item, loading, saving, errors, handleSubmit, goBack };
  },
};
</script>

<style scoped>
.edit-page {
  padding: 0;
}
</style>
