<template>
  <div class="create-page space-y-6">
    <!-- Action Bar -->
    <div class="page-header flex justify-between items-center">
      <div>
        <h1 class="page-title text-xl font-bold text-slate-800">Create Mock Test Module</h1>
        <p class="text-xs text-slate-500 mt-0.5">Scaffold a new Mock Test Module entry in your system</p>
      </div>
      <div>
        <a-button @click="goBack" class="btn-outline">
          Back to List
        </a-button>
      </div>
    </div>

    <!-- Form Card -->
    <div class="bg-white border border-slate-200 rounded-lg shadow-sm p-6 max-w-3xl">
      <Form
        submit-label="Create Entry"
        :busy="saving"
        :errors="errors"
        @submit="handleSubmit"
        @cancel="goBack"
      />
    </div>
  </div>
</template>

<script>
import { ref, reactive } from 'vue';
import { useRouter, useRoute } from 'vue-router';
import axios from 'axios';
import { message } from 'ant-design-vue';
import Form from '../../components/Form.vue';

export default {
  name: 'MockTestModuleCreate',
  components: { Form },
  setup() {
    const router = useRouter();
    const route = useRoute();
    const saving = ref(false);
    const errors = reactive({});
    const moduleSlug = route.params.slug;

    const handleSubmit = async (form) => {
      saving.value = true;
      Object.keys(errors).forEach(k => delete errors[k]);
      try {
        await axios.post('/api/mock-test-module', { ...form });
        message.success('Created successfully.');
        router.push(`/admin/module/${moduleSlug}/mock-test-modules`);
      } catch (e) {
        const resp = e.response?.data;
        if (resp?.errors) {
          Object.assign(errors, resp.errors);
        }
        message.error(resp?.message || 'Failed to create.');
      } finally {
        saving.value = false;
      }
    };

    const goBack = () => {
      router.push(`/admin/module/${moduleSlug}/mock-test-modules`);
    };

    return { saving, errors, handleSubmit, goBack };
  },
};
</script>

<style scoped>
.create-page {
  padding: 0;
}
</style>
