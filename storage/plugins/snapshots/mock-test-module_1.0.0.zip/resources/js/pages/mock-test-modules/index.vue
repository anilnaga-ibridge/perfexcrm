<template>
  <div class="list-page space-y-6">
    <!-- Action Bar -->
    <div class="page-header flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
      <div>
        <h1 class="page-title text-xl font-bold text-slate-800">Mock Test Modules</h1>
        <p class="text-xs text-slate-500 mt-0.5">Manage and track your Mock Test Modules database</p>
      </div>
      <div class="flex items-center gap-2">
        <router-link :to="`/admin/module/${moduleSlug}/mock-test-modules/create`" class="btn-primary flex items-center">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" width="13" height="13" class="mr-1.5"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
          Create New
        </router-link>
      </div>
    </div>

    <!-- Data Table Card -->
    <div class="table-card bg-white border border-slate-200 rounded-lg shadow-sm">
      <div class="table-toolbar p-4 border-b border-slate-100 flex flex-col sm:flex-row justify-between items-center gap-4">
        <div class="toolbar-left flex items-center space-x-3">
          <select class="select-sm" v-model="pagination.pageSize" @change="onPageSizeChange">
            <option :value="10">10</option>
            <option :value="25">25</option>
            <option :value="50">50</option>
          </select>
          <span class="total-badge text-xs text-slate-500">{{ pagination.total }} item{{ pagination.total !== 1 ? 's' : '' }}</span>
        </div>
        <div class="toolbar-right">
          <input 
            class="input-sm" 
            v-model="search" 
            placeholder="Search..." 
            @input="onSearch"
          />
        </div>
      </div>

      <a-table
        :columns="columns"
        :data-source="items"
        :row-key="record => record.id"
        :pagination="pagination"
        :loading="loading"
        @change="handleTableChange"
        size="small"
      >
        <template #bodyCell="{ column, record }">
          <template v-if="column.key === 'title'">
            <span class="font-semibold text-slate-800 hover:text-indigo-600 cursor-pointer link-blue" @click="editItem(record.id)">
              {{ record.title }}
            </span>
          </template>

          <template v-if="column.key === 'status'">
            <span class="badge" :class="record.status === 'published' ? 'badge-green' : (record.status === 'draft' ? 'badge-amber' : 'badge-red')">
              {{ record.status }}
            </span>
          </template>

          <template v-if="column.key === 'created_at'">
            <span class="text-slate-500 text-xs">{{ formatDate(record.created_at) }}</span>
          </template>

          <template v-if="column.key === 'actions'">
            <div class="flex items-center space-x-3">
              <a-button type="link" size="small" @click="editItem(record.id)" class="text-indigo-600 p-0 hover:text-indigo-800 font-medium">Edit</a-button>
              <a-popconfirm
                title="Are you sure you want to delete this item?"
                ok-text="Yes"
                cancel-text="No"
                @confirm="doDelete(record.id)"
              >
                <a-button type="link" size="small" danger class="p-0 font-medium">Delete</a-button>
              </a-popconfirm>
            </div>
          </template>
        </template>
      </a-table>
    </div>
  </div>
</template>

<script>
import { ref, reactive, onMounted } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import axios from 'axios';
import { message } from 'ant-design-vue';

export default {
  name: 'MockTestModuleList',
  setup() {
    const route = useRoute();
    const router = useRouter();
    const moduleSlug = route.params.slug;
    const items = ref([]);
    const loading = ref(true);
    const search = ref('');
    let searchTimeout = null;

    const pagination = reactive({
      current: 1,
      pageSize: 10,
      total: 0,
      showSizeChanger: false,
    });

    const columns = [
      { title: 'Title', dataIndex: 'title', key: 'title', customFilterDropdown: true },
      { title: 'Status', dataIndex: 'status', key: 'status' },
      { title: 'Created At', dataIndex: 'created_at', key: 'created_at' },
      { title: '', key: 'actions', width: 120 },
    ];

    const fetchItems = async () => {
      loading.value = true;
      try {
        const params = {
          page: pagination.current,
          per_page: pagination.pageSize,
        };
        if (search.value) params.search = search.value;
        const { data } = await axios.get('/api/mock-test-module', { params });
        items.value = data.data;
        pagination.total = data.meta.total;
        pagination.current = data.meta.current_page;
      } catch (e) {
        console.error('Failed to fetch:', e);
        items.value = [];
      } finally {
        loading.value = false;
      }
    };

    const onSearch = () => {
      clearTimeout(searchTimeout);
      searchTimeout = setTimeout(() => {
        pagination.current = 1;
        fetchItems();
      }, 300);
    };

    const onPageSizeChange = () => {
      pagination.current = 1;
      fetchItems();
    };

    const handleTableChange = (pag) => {
      pagination.current = pag.current;
      fetchItems();
    };

    const formatDate = (dateStr) => {
      if (!dateStr) return '\u2014';
      const d = new Date(dateStr);
      return d.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
    };

    const editItem = (id) => {
      router.push(`/admin/module/${moduleSlug}/mock-test-modules/edit?id=${id}`);
    };

    const doDelete = async (id) => {
      try {
        await axios.delete(`/api/mock-test-module/${id}`);
        message.success('Deleted successfully.');
        await fetchItems();
      } catch (e) {
        message.error(e.response?.data?.message || 'Failed to delete.');
      }
    };

    onMounted(fetchItems);

    return {
      moduleSlug,
      items,
      columns,
      pagination,
      loading,
      search,
      onSearch,
      onPageSizeChange,
      handleTableChange,
      formatDate,
      editItem,
      doDelete,
    };
  },
};
</script>

<style scoped>
.list-page {
  padding: 0;
}
</style>
