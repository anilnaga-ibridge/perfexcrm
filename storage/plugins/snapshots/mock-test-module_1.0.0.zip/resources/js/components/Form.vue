<template>
  <a-form layout="vertical" class="premium-form-layout">
    <a-form-item label="Title" required :validate-status="errors.title ? 'error' : ''" :help="errors.title">
      <a-input v-model:value="form.title" placeholder="Enter title" class="form-input-premium" />
    </a-form-item>

    <a-form-item label="Status" required :validate-status="errors.status ? 'error' : ''" :help="errors.status">
      <a-select v-model:value="form.status" class="form-select-premium">
        <a-select-option value="draft">Draft</a-select-option>
        <a-select-option value="published">Published</a-select-option>
        <a-select-option value="archived">Archived</a-select-option>
      </a-select>
    </a-form-item>

    <a-form-item label="Description" :validate-status="errors.description ? 'error' : ''" :help="errors.description">
      <a-textarea v-model:value="form.description" placeholder="Brief description" :rows="3" />
    </a-form-item>

    <a-form-item label="Content" :validate-status="errors.content ? 'error' : ''" :help="errors.content">
      <a-textarea v-model:value="form.content" placeholder="Full content..." :rows="8" />
    </a-form-item>

    <div class="form-actions flex justify-end gap-2 pt-4 border-t border-slate-100">
      <a-button @click="$emit('cancel')" class="btn-cancel-ant">Cancel</a-button>
      <a-button type="primary" @click="$emit('submit', form)" :loading="busy" class="btn-primary-ant">
        {{ submitLabel }}
      </a-button>
    </div>
  </a-form>
</template>

<script>
import { reactive, watch } from 'vue';

export default {
  name: 'MockTestModuleForm',
  props: {
    initial: { type: Object, default: () => ({}) },
    submitLabel: { type: String, default: 'Save' },
    busy: { type: Boolean, default: false },
    errors: { type: Object, default: () => ({}) },
  },
  emits: ['submit', 'cancel'],
  setup(props) {
    const form = reactive({
      title: '',
      description: '',
      content: '',
      status: 'draft',
    });

    watch(() => props.initial, (val) => {
      if (val && val.id) {
        form.title = val.title || '';
        form.description = val.description || '';
        form.content = val.content || '';
        form.status = val.status || 'draft';
      }
    }, { immediate: true });

    return { form };
  },
};
</script>

<style scoped>
.premium-form-layout {
  max-width: 100%;
}
.btn-primary-ant {
  background: linear-gradient(135deg, #6366f1, #8b5cf6) !important;
  border: none !important;
  color: #fff !important;
  font-weight: 500;
  border-radius: 6px !important;
  height: 38px;
}
.btn-cancel-ant {
  border-radius: 6px !important;
  height: 38px;
}
</style>
