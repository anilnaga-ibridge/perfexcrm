<?php

namespace Modules\Tests\Feature;

use Tests\TestCase;

class MockTestModuleTest extends TestCase
{
    public function test_can_list_items(): void
    {
        $response = $this->getJson('/api/mock-test-module');

        $response->assertStatus(200)
            ->assertJsonStructure([
                'success',
                'data',
                'meta' => ['current_page', 'last_page', 'per_page', 'total'],
            ]);
    }
}
