<?php
namespace Modules\MockTestModule\Tests\Feature;
use Tests\TestCase;
class ExampleTest extends TestCase {
    public function test_example() { $this->assertTrue(true); }
}