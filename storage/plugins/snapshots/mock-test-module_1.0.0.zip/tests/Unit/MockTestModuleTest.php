<?php

namespace Modules\MockTestModule\Tests\Unit;

use Tests\TestCase;

/**
 * Class UnitTest
 * 
 * Auto-generated unit tests for Mock Test Module plugin.
 */
class UnitTest extends TestCase
{
    /**
     * A basic unit test.
     */
    public function test_basic_addition(): void
    {
        $this->assertTrue(true);
    }
}
