<?php

namespace Modules\MockTestModule\Events;

use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

/**
 * Class PluginEvent
 * 
 * Auto-generated event triggered by Mock Test Module plugin.
 */
class PluginEvent
{
    use Dispatchable, SerializesModels;

    public array $data;

    public function __construct(array $data)
    {
        $this->data = $data;
    }
}
