<?php

namespace Modules\MockTestModule\Console\Commands;

use Illuminate\Console\Command;

/**
 * Class PluginCommand
 * 
 * Auto-generated command for Mock Test Module plugin.
 */
class PluginCommand extends Command
{
    /**
     * The name and signature of the console command.
     */
    protected $signature = 'mock-test-module:sync';

    /**
     * The console command description.
     */
    protected $description = 'Synchronize data for Mock Test Module plugin';

    /**
     * Execute the console command.
     */
    public function handle(): int
    {
        $this->info('Mock Test Module command executed successfully!');
        return Command::SUCCESS;
    }
}
