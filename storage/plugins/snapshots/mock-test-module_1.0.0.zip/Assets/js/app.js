console.log('Mock Test Module plugin assets loaded successfully.');
