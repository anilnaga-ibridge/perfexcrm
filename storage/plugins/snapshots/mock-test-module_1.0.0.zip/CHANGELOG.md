# Changelog

All notable changes to the "Mock Test Module" plugin will be documented in this file.

## [1.0.0] - 2026-07-11
- Initial scaffolded release of Mock Test Module plugin.
