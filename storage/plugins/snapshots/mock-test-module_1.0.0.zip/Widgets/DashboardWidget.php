<?php

namespace Modules\MockTestModule\Widgets;

use App\Contracts\Plugins\WidgetInterface;

/**
 * Class DashboardWidget
 * 
 * Auto-generated dashboard widget for Mock Test Module plugin.
 */
class DashboardWidget implements WidgetInterface
{
    public function getId(): string
    {
        return 'mock-test-module_dashboard_widget';
    }

    public function getTitle(): string
    {
        return 'Mock Test Module Stats';
    }

    public function getSize(): string
    {
        return 'half';
    }

    public function render(): string
    {
        return 'mock-test-module::widgets.dashboard';
    }

    public function getData(): array
    {
        return [
            'count' => 10,
        ];
    }
}
