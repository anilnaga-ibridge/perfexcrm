<?php

$lang['mock_test_module_title'] = 'Mock Test Module';
$lang['mock_test_module_dashboard'] = 'Mock Test Module Dashboard';
