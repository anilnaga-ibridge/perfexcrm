<?php

namespace Modules\MockTestModule\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class UpdateMockTestModuleRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'title' => 'sometimes|required|string|max:255',
            'description' => 'nullable|string|max:1000',
            'content' => 'nullable|string',
            'status' => 'sometimes|required|in:draft,published,archived',
        ];
    }

    public function messages(): array
    {
        return [
            'title.required' => 'A title is required.',
            'status.in' => 'Status must be draft, published, or archived.',
        ];
    }
}
