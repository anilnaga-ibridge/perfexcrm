<?php

namespace Modules\MockTestModule\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreMockTestModuleRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'title' => 'required|string|max:255',
            'description' => 'nullable|string|max:1000',
            'content' => 'nullable|string',
            'status' => 'required|in:draft,published,archived',
        ];
    }

    public function messages(): array
    {
        return [
            'title.required' => 'A title is required.',
            'status.in' => 'Status must be draft, published, or archived.',
        ];
    }
}
