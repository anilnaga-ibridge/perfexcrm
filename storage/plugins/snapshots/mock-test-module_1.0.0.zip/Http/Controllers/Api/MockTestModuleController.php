<?php

namespace Modules\MockTestModule\Http\Controllers\Api;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Modules\MockTestModule\Models\MockTestModule;
use Modules\MockTestModule\Http\Requests\StoreMockTestModuleRequest;
use Modules\MockTestModule\Http\Requests\UpdateMockTestModuleRequest;

class MockTestModuleController
{
    public function index(Request $request): JsonResponse
    {
        $query = MockTestModule::query();

        if ($search = $request->get('search')) {
            $query->where(function ($q) use ($search) {
                $q->where('title', 'like', "%{$search}%")
                  ->orWhere('description', 'like', "%{$search}%");
            });
        }

        $perPage = min((int) $request->get('per_page', 15), 100);
        $items = $query->orderBy('created_at', 'desc')->paginate($perPage);

        return response()->json([
            'success' => true,
            'data' => $items->items(),
            'meta' => [
                'current_page' => $items->currentPage(),
                'last_page' => $items->lastPage(),
                'per_page' => $items->perPage(),
                'total' => $items->total(),
            ],
        ]);
    }

    public function show(string $id): JsonResponse
    {
        $item = MockTestModule::findOrFail($id);

        return response()->json([
            'success' => true,
            'data' => $item,
        ]);
    }

    public function store(StoreMockTestModuleRequest $request): JsonResponse
    {
        $item = MockTestModule::create([
            'title' => $request->title,
            'description' => $request->description,
            'content' => $request->content,
            'status' => $request->status,
            'created_by' => $request->user()?->id,
        ]);

        return response()->json([
            'success' => true,
            'message' => 'MockTestModule created successfully.',
            'data' => $item,
        ], 201);
    }

    public function update(UpdateMockTestModuleRequest $request, string $id): JsonResponse
    {
        $item = MockTestModule::findOrFail($id);
        $item->update($request->only([
            'title', 'description', 'content', 'status',
        ]));

        return response()->json([
            'success' => true,
            'message' => 'MockTestModule updated successfully.',
            'data' => $item->fresh(),
        ]);
    }

    public function destroy(string $id): JsonResponse
    {
        $item = MockTestModule::findOrFail($id);
        $item->delete();

        return response()->json([
            'success' => true,
            'message' => 'MockTestModule deleted successfully.',
        ]);
    }
}
