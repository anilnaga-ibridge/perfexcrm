<?php

namespace Modules\MockTestModule\Providers;

use App\Plugin\Providers\PluginServiceProvider as BaseProvider;

/**
 * Class PluginServiceProvider
 * 
 * Auto-generated Service Provider for Mock Test Module plugin.
 */
class PluginServiceProvider extends BaseProvider
{
    /**
     * Register any plugin services.
     */
    public function register(): void
    {
        // Register configuration
        $this->registerConfig('mock-test-module', [
            'name' => 'Mock Test Module',
            'version' => '1.0.0',
        ]);
    }

    /**
     * Bootstrap any plugin services.
     */
    public function boot(): void
    {
        // Register web and api routes
        $this->registerRoutes(
            __DIR__ . '/../routes/web.php',
            __DIR__ . '/../routes/api.php',
            "Modules\\MockTestModule\\Controllers"
        );

        // Register Blade views
        $this->registerViews(__DIR__ . '/../Views', 'mock-test-module');

        // Register localizations/translations
        $this->registerTranslations(__DIR__ . '/../language', 'mock-test-module');
    }
}
