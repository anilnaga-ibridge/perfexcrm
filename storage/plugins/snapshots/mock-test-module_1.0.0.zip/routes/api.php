<?php

use Illuminate\Support\Facades\Route;
use Modules\MockTestModule\Http\Controllers\Api\MockTestModuleController;

Route::get('mock-test-module', [MockTestModuleController::class, 'index']);
Route::get('mock-test-module/{id}', [MockTestModuleController::class, 'show']);
Route::post('mock-test-module', [MockTestModuleController::class, 'store']);
Route::put('mock-test-module/{id}', [MockTestModuleController::class, 'update']);
Route::delete('mock-test-module/{id}', [MockTestModuleController::class, 'destroy']);
