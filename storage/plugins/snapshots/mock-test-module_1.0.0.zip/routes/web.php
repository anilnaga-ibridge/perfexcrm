<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your plugin.
|
*/

Route::get('mock-test-module/dashboard', function () {
    return view('mock-test-module::index');
});
