<?php

namespace Modules\MockTestModule\Policies;

use App\Models\User;
use Modules\MockTestModule\Models\MockTestModule;
use Illuminate\Auth\Access\HandlesAuthorization;

/**
 * Class PluginPolicy
 * 
 * Auto-generated access policy for Mock Test Module plugin.
 */
class PluginPolicy
{
    use HandlesAuthorization;

    /**
     * Determine whether the user can view any models.
     */
    public function viewAny(User $user): bool
    {
        return true;
    }

    /**
     * Determine whether the user can create models.
     */
    public function create(User $user): bool
    {
        return true;
    }

    /**
     * Determine whether the user can update the model.
     */
    public function update(User $user, MockTestModule $model): bool
    {
        return true;
    }

    /**
     * Determine whether the user can delete the model.
     */
    public function delete(User $user, MockTestModule $model): bool
    {
        return true;
    }
}
