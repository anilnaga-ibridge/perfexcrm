<div class="card">
    <div class="card-header">
        <h3>Mock Test Module Widget Statistics</h3>
    </div>
    <div class="card-body">
        <p>Total items counted: <strong>{{ $count }}</strong></p>
    </div>
</div>
