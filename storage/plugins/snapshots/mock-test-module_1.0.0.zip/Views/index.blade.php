<!DOCTYPE html>
<html>
<head>
    <title>Mock Test Module - Admin Dashboard</title>
</head>
<body>
    <h1>Welcome to Mock Test Module Dashboard!</h1>
    <p>This is a dynamic blade view registered from the plugin.</p>
</body>
</html>
