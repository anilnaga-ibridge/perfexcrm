<?php

namespace Modules\MockTestModule\Listeners;

use Modules\MockTestModule\Events\PluginEvent;

/**
 * Class PluginListener
 * 
 * Auto-generated event listener for Mock Test Module plugin.
 */
class PluginListener
{
    /**
     * Handle the event.
     */
    public function handle(PluginEvent $event): void
    {
        // Event processing logic
    }
}
