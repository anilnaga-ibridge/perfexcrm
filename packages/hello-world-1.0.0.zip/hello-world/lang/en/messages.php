<?php

return [
    'welcome' => 'Welcome to the Hello World module!',
];
