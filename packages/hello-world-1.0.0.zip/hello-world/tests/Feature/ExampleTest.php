<?php

namespace Modules\HelloWorld\Tests\Feature;

use Tests\TestCase;

class ExampleTest extends TestCase
{
    public function test_basic_hello_world_features()
    {
        $this->assertTrue(true);
    }
}
