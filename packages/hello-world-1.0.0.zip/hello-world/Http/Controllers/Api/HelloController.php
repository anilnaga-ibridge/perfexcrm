<?php
namespace Modules\HelloWorld\Http\Controllers\Api;
use Illuminate\Http\JsonResponse;
class HelloController
{
    public function dashboard(): JsonResponse
    {
        return response()->json([
            'success' => true,
            'message' => 'Hello from the native module runtime!',
            'data' => [
                'module' => 'Hello World',
                'version' => '1.0.0',
                'status' => 'active',
                'timestamp' => now()->toIso8601String(),
            ],
        ]);
    }
    public function about(): JsonResponse
    {
        return response()->json([
            'success' => true,
            'message' => 'Hello World Module - Platform Validation',
            'data' => [
                'name' => 'Hello World',
                'alias' => 'hello-world',
                'version' => '1.0.0',
                'description' => 'A minimal native module to validate the platform runtime.',
                'author' => 'Platform Test',
                'vue_pages' => ['Dashboard', 'About'],
            ],
        ]);
    }
    public function webInfo(): JsonResponse
    {
        return response()->json([
            'message' => 'Hello World web route loaded successfully.',
        ]);
    }
}
