<?php
use Illuminate\Support\Facades\Route;
use Modules\HelloWorld\Http\Controllers\Api\HelloController;
Route::get('hello-world/dashboard', [HelloController::class, 'dashboard']);
Route::get('hello-world/about', [HelloController::class, 'about']);
