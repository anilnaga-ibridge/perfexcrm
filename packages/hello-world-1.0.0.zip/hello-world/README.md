# Hello World Module

A minimal native module used to test and validate SDK compliance on the PerfexCRM Modular Platform.
