<template>
  <div class="hello-about">
    <div class="page-header"><h1>About Hello World</h1></div>
    <div class="card" v-if="data">
      <div class="card-body">
        <p class="greeting">{{ data.message }}</p>
        <div class="info-grid">
          <div class="info-item"><span class="label">Name</span><span class="value">{{ data.data.name }}</span></div>
          <div class="info-item"><span class="label">Alias</span><span class="value">{{ data.data.alias }}</span></div>
          <div class="info-item"><span class="label">Version</span><span class="value">{{ data.data.version }}</span></div>
          <div class="info-item"><span class="label">Author</span><span class="value">{{ data.data.author }}</span></div>
          <div class="info-item full-width"><span class="label">Description</span><span class="value">{{ data.data.description }}</span></div>
          <div class="info-item full-width"><span class="label">Vue Pages</span><span class="value">{{ data.data.vue_pages.join(', ') }}</span></div>
        </div>
      </div>
    </div>
    <div class="card loading" v-else-if="loading"><p>Loading API response...</p></div>
    <div class="card error" v-else><p>Failed to load data.</p></div>
  </div>
</template>
<script>
import { ref, onMounted } from 'vue'; import axios from 'axios';
export default {
  name: 'HelloAbout',
  setup() {
    const data = ref(null); const loading = ref(true);
    onMounted(async () => {
      try { const r = await axios.get('/api/hello-world/about'); data.value = r.data; }
      catch (e) { console.error('API error:', e); } finally { loading.value = false; }
    });
    return { data, loading };
  },
};
</script>
<style scoped>
.hello-about { padding: 20px; }
.page-header { margin-bottom: 20px; }
.page-header h1 { font-size: 24px; font-weight: 700; color: #1e293b; margin: 0; }
.card { background: #fff; border: 1px solid #e2e8f0; border-radius: 8px; padding: 24px; }
.greeting { font-size: 18px; font-weight: 600; color: #0f172a; margin-bottom: 20px; }
.info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
.info-item { display: flex; flex-direction: column; gap: 4px; }
.info-item.full-width { grid-column: 1 / -1; }
.label { font-size: 12px; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px; }
.value { font-size: 14px; color: #1e293b; }
.loading, .error { text-align: center; padding: 40px; color: #64748b; }
</style>
