<template>
  <div class="hello-dashboard">
    <div class="page-header"><h1>Hello World Dashboard</h1></div>
    <div class="card" v-if="data">
      <div class="card-body">
        <p class="greeting">{{ data.message }}</p>
        <div class="info-grid">
          <div class="info-item"><span class="label">Module</span><span class="value">{{ data.data.module }}</span></div>
          <div class="info-item"><span class="label">Version</span><span class="value">{{ data.data.version }}</span></div>
          <div class="info-item"><span class="label">Status</span><span class="value badge-success">{{ data.data.status }}</span></div>
          <div class="info-item"><span class="label">Timestamp</span><span class="value">{{ data.data.timestamp }}</span></div>
        </div>
      </div>
    </div>
    <div class="card loading" v-else-if="loading"><p>Loading API response...</p></div>
    <div class="card error" v-else><p>Failed to load data.</p></div>
  </div>
</template>
<script>
import { ref, onMounted } from 'vue'; import axios from 'axios';
export default {
  name: 'HelloDashboard',
  setup() {
    const data = ref(null); const loading = ref(true);
    onMounted(async () => {
      try { const r = await axios.get('/api/hello-world/dashboard'); data.value = r.data; }
      catch (e) { console.error('API error:', e); } finally { loading.value = false; }
    });
    return { data, loading };
  },
};
</script>
<style scoped>
.hello-dashboard { padding: 20px; }
.page-header { margin-bottom: 20px; }
.page-header h1 { font-size: 24px; font-weight: 700; color: #1e293b; margin: 0; }
.card { background: #fff; border: 1px solid #e2e8f0; border-radius: 8px; padding: 24px; }
.greeting { font-size: 18px; font-weight: 600; color: #0f172a; margin-bottom: 20px; }
.info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
.info-item { display: flex; flex-direction: column; gap: 4px; }
.label { font-size: 12px; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px; }
.value { font-size: 14px; color: #1e293b; }
.badge-success { color: #059669; font-weight: 600; }
.loading, .error { text-align: center; padding: 40px; color: #64748b; }
</style>
