@extends('hrm::layout')

@section('content')
<div class="mb-6 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
    <div>
        <h1 class="text-xl md:text-2xl font-bold text-slate-800 tracking-tight">HRM Dashboard</h1>
        <p class="text-sm text-slate-500">Overview of human resources status, leaves, attendance, and payouts</p>
    </div>
    <div class="text-xs font-semibold text-slate-400 bg-white border border-slate-200 px-3 py-1.5 rounded-lg shadow-sm">
        Month: {{ date('F Y') }}
    </div>
</div>

<!-- Stats Grid -->
<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
    <!-- Card 1 -->
    <div class="bg-white p-6 rounded-xl border border-slate-150 shadow-sm flex items-center gap-4 hover:shadow-md transition-shadow">
        <div class="p-3 bg-indigo-50 text-indigo-600 rounded-xl">
            <svg class="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
            </svg>
        </div>
        <div>
            <span class="text-xs font-semibold text-slate-400 uppercase tracking-wider block">Total Employees</span>
            <span class="text-2xl font-bold text-slate-800">{{ $stats['total_employees'] }}</span>
        </div>
    </div>
    <!-- Card 2 -->
    <div class="bg-white p-6 rounded-xl border border-slate-150 shadow-sm flex items-center gap-4 hover:shadow-md transition-shadow">
        <div class="p-3 bg-emerald-50 text-emerald-600 rounded-xl">
            <svg class="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4" />
            </svg>
        </div>
        <div>
            <span class="text-xs font-semibold text-slate-400 uppercase tracking-wider block">Present Today</span>
            <span class="text-2xl font-bold text-slate-800">{{ $stats['present_today'] }}</span>
        </div>
    </div>
    <!-- Card 3 -->
    <div class="bg-white p-6 rounded-xl border border-slate-150 shadow-sm flex items-center gap-4 hover:shadow-md transition-shadow">
        <div class="p-3 bg-orange-50 text-orange-600 rounded-xl">
            <svg class="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
            </svg>
        </div>
        <div>
            <span class="text-xs font-semibold text-slate-400 uppercase tracking-wider block">Pending Leaves</span>
            <span class="text-2xl font-bold text-slate-800">{{ $stats['pending_leaves'] }}</span>
        </div>
    </div>
    <!-- Card 4 -->
    <div class="bg-white p-6 rounded-xl border border-slate-150 shadow-sm flex items-center gap-4 hover:shadow-md transition-shadow">
        <div class="p-3 bg-rose-50 text-rose-600 rounded-xl">
            <svg class="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M12 16v1m-4-6h8" />
            </svg>
        </div>
        <div>
            <span class="text-xs font-semibold text-slate-400 uppercase tracking-wider block">Monthly Payouts</span>
            <span class="text-2xl font-bold text-slate-800">${{ number_format($stats['processed_payroll'], 2) }}</span>
        </div>
    </div>
</div>

<div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
    <div class="lg:col-span-2 bg-white rounded-xl border border-slate-150 p-6 shadow-sm">
        <h2 class="text-base font-bold text-slate-800 mb-4">Quick Management Actions</h2>
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <a href="/admin/module/hrm/employees" class="p-4 bg-slate-50 border border-slate-150 hover:bg-indigo-50/30 hover:border-indigo-200 transition rounded-xl flex items-center gap-3">
                <div class="p-2 bg-indigo-500/10 text-indigo-600 rounded-lg">
                    <svg class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
                </div>
                <div>
                    <span class="font-semibold text-sm text-slate-700 block">Manage Directory</span>
                    <span class="text-xs text-slate-400">Add or edit employee profiles</span>
                </div>
            </a>
            <a href="/admin/module/hrm/attendance" class="p-4 bg-slate-50 border border-slate-150 hover:bg-emerald-50/30 hover:border-emerald-200 transition rounded-xl flex items-center gap-3">
                <div class="p-2 bg-emerald-500/10 text-emerald-600 rounded-lg">
                    <svg class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2"/></svg>
                </div>
                <div>
                    <span class="font-semibold text-sm text-slate-700 block">Mark Attendance</span>
                    <span class="text-xs text-slate-400">Log today's clock in/out times</span>
                </div>
            </a>
        </div>
    </div>
    
    <div class="bg-white rounded-xl border border-slate-150 p-6 shadow-sm">
        <h2 class="text-base font-bold text-slate-800 mb-4">Module Health & Core Integrity</h2>
        <div class="space-y-4">
            <div class="flex items-center justify-between text-sm">
                <span class="text-slate-500">Core Authentication:</span>
                <span class="font-semibold text-emerald-600 flex items-center gap-1">
                    <span class="w-2 h-2 rounded-full bg-emerald-500"></span> Shared Session
                </span>
            </div>
            <div class="flex items-center justify-between text-sm">
                <span class="text-slate-500">Database Connection:</span>
                <span class="font-semibold text-emerald-600 flex items-center gap-1">
                    <span class="w-2 h-2 rounded-full bg-emerald-500"></span> Connected
                </span>
            </div>
            <div class="flex items-center justify-between text-sm">
                <span class="text-slate-500">Module Health:</span>
                <span class="font-semibold text-emerald-600 flex items-center gap-1">
                    <span class="w-2 h-2 rounded-full bg-emerald-500"></span> Excellent
                </span>
            </div>
        </div>
    </div>
</div>
@endsection
