@extends('hrm::layout')

@section('content')
<div class="mb-6 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
    <div>
        <h1 class="text-xl md:text-2xl font-bold text-slate-800 tracking-tight">Staff Directory</h1>
        <p class="text-sm text-slate-500">View and manage employee profile records and salaries</p>
    </div>
</div>

<div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
    <!-- Employees Table -->
    <div class="lg:col-span-2 bg-white rounded-xl border border-slate-150 p-6 shadow-sm overflow-hidden flex flex-col">
        <h2 class="text-base font-bold text-slate-800 mb-4">Employees List</h2>
        <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse text-sm">
                <thead>
                    <tr class="border-b border-slate-100 text-slate-400 font-semibold">
                        <th class="py-3 px-4">Employee ID</th>
                        <th class="py-3 px-4">Name</th>
                        <th class="py-3 px-4">Email</th>
                        <th class="py-3 px-4">Dept / Desg</th>
                        <th class="py-3 px-4">Salary</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 text-slate-600">
                    @forelse($employees as $emp)
                        <tr class="hover:bg-slate-50/50 transition-colors">
                            <td class="py-3 px-4 font-mono font-medium text-xs text-indigo-600">{{ $emp->employee_id }}</td>
                            <td class="py-3 px-4 font-semibold text-slate-800">{{ $emp->user->name ?? 'N/A' }}</td>
                            <td class="py-3 px-4 text-xs">{{ $emp->user->email ?? 'N/A' }}</td>
                            <td class="py-3 px-4">
                                <span class="block text-xs font-semibold text-slate-700">{{ $emp->department->name ?? 'N/A' }}</span>
                                <span class="block text-[10px] text-slate-400">{{ $emp->designation->name ?? 'N/A' }}</span>
                            </td>
                            <td class="py-3 px-4 font-medium text-slate-800">${{ number_format($emp->salary, 2) }}</td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="5" class="py-8 px-4 text-center text-slate-400">No employee records found.</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>

    <!-- Add Employee Form -->
    <div class="bg-white rounded-xl border border-slate-150 p-6 shadow-sm">
        <h2 class="text-base font-bold text-slate-800 mb-4">Add Employee</h2>
        <form action="/modules/hrm/employees" method="POST" class="space-y-4">
            @csrf
            <div>
                <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">* Full Name</label>
                <input type="text" name="name" required class="w-full text-sm border border-slate-200 rounded-lg px-3 py-2 focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition" placeholder="e.g. Alex Chen" />
            </div>
            <div>
                <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">* Email Address</label>
                <input type="email" name="email" required class="w-full text-sm border border-slate-200 rounded-lg px-3 py-2 focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition" placeholder="e.g. alex@example.com" />
            </div>
            <div>
                <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">* Employee ID</label>
                <input type="text" name="employee_id" required class="w-full text-sm border border-slate-200 rounded-lg px-3 py-2 focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition" placeholder="e.g. EMP-001" />
            </div>
            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">* Joining Date</label>
                    <input type="date" name="joining_date" required class="w-full text-sm border border-slate-200 rounded-lg px-3 py-2 focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition" />
                </div>
                <div>
                    <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">* Base Salary</label>
                    <input type="number" name="salary" required min="0" step="0.01" class="w-full text-sm border border-slate-200 rounded-lg px-3 py-2 focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition" placeholder="4500" />
                </div>
            </div>
            <div>
                <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">* Department</label>
                <select name="department_id" required class="w-full text-sm border border-slate-200 rounded-lg px-3 py-2 focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition bg-white">
                    @foreach($departments as $dept)
                        <option value="{{ $dept->id }}">{{ $dept->name }}</option>
                    @endforeach
                </select>
            </div>
            <div>
                <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">* Designation</label>
                <select name="designation_id" required class="w-full text-sm border border-slate-200 rounded-lg px-3 py-2 focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition bg-white">
                    @foreach($designations as $desg)
                        <option value="{{ $desg->id }}">{{ $desg->name }}</option>
                    @endforeach
                </select>
            </div>
            <button type="submit" class="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-sm rounded-lg shadow transition">
                Register Employee
            </button>
        </form>
    </div>
</div>
@endsection
