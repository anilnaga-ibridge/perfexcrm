<?php

namespace Modules\HRM\Controllers;

use App\Http\Controllers\Controller;
use App\Models\User;
use Modules\HRM\Models\HrmEmployee;
use Modules\HRM\Models\HrmDepartment;
use Modules\HRM\Models\HrmDesignation;
use Modules\HRM\Models\HrmAttendance;
use Modules\HRM\Models\HrmLeave;
use Modules\HRM\Models\HrmPayroll;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;

class HrmController extends Controller
{
    public function dashboard()
    {
        $today = Carbon::today()->toDateString();
        $month = Carbon::now()->format('Y-m');

        $stats = [
            'total_employees' => HrmEmployee::where('status', 'active')->count(),
            'present_today' => HrmAttendance::where('date', $today)->where('status', 'present')->count(),
            'pending_leaves' => HrmLeave::where('status', 'pending')->count(),
            'processed_payroll' => HrmPayroll::where('month', $month)->sum('net_pay'),
        ];

        // Seed default departments & designations if empty so the UX looks perfect immediately
        if (HrmDepartment::count() === 0) {
            HrmDepartment::create(['name' => 'Engineering', 'description' => 'Software developers and QA engineers']);
            HrmDepartment::create(['name' => 'Human Resources', 'description' => 'Talent acquisition and employees welfare']);
            HrmDepartment::create(['name' => 'Marketing', 'description' => 'Brand and advertising operations']);
        }
        if (HrmDesignation::count() === 0) {
            HrmDesignation::create(['name' => 'Senior Developer', 'description' => 'Technical lead']);
            HrmDesignation::create(['name' => 'HR Manager', 'description' => 'Department head']);
            HrmDesignation::create(['name' => 'Product Designer', 'description' => 'UI/UX specialist']);
        }

        return view('hrm::dashboard', compact('stats'));
    }

    public function employees()
    {
        $employees = HrmEmployee::with(['user', 'department', 'designation'])->get();
        $departments = HrmDepartment::all();
        $designations = HrmDesignation::all();

        return view('hrm::employees', compact('employees', 'departments', 'designations'));
    }

    public function attendance()
    {
        $attendances = HrmAttendance::with('employee.user')->orderBy('date', 'desc')->get();
        $employees = HrmEmployee::with('user')->where('status', 'active')->get();

        return view('hrm::attendance', compact('attendances', 'employees'));
    }

    public function leaves()
    {
        $leaves = HrmLeave::with('employee.user')->orderBy('created_at', 'desc')->get();
        $employees = HrmEmployee::with('user')->where('status', 'active')->get();

        return view('hrm::leaves', compact('leaves', 'employees'));
    }

    public function payroll()
    {
        $payrolls = HrmPayroll::with('employee.user')->orderBy('month', 'desc')->get();
        $employees = HrmEmployee::with('user')->where('status', 'active')->get();

        return view('hrm::payroll', compact('payrolls', 'employees'));
    }

    public function storeEmployee(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|max:255',
            'employee_id' => 'required|string|unique:hrm_employees,employee_id',
            'joining_date' => 'required|date',
            'salary' => 'required|numeric|min:0',
            'department_id' => 'required|exists:hrm_departments,id',
            'designation_id' => 'required|exists:hrm_designations,id',
        ]);

        // Find or create core User
        $user = User::where('email', $request->email)->first();
        if (!$user) {
            $user = User::create([
                'name' => $request->name,
                'email' => $request->email,
                'password' => Hash::make('welcome123'),
                'role' => 'staff',
            ]);
        }

        HrmEmployee::create([
            'user_id' => $user->id,
            'department_id' => $request->department_id,
            'designation_id' => $request->designation_id,
            'employee_id' => $request->employee_id,
            'joining_date' => $request->joining_date,
            'salary' => $request->salary,
            'status' => 'active',
        ]);

        return redirect()->back()->with('success', 'Employee registered successfully.');
    }

    public function markAttendance(Request $request)
    {
        $request->validate([
            'employee_id' => 'required|exists:hrm_employees,id',
            'status' => 'required|in:present,late,absent,half_day',
            'clock_in' => 'nullable|string',
            'clock_out' => 'nullable|string',
        ]);

        $today = Carbon::today()->toDateString();

        HrmAttendance::updateOrCreate(
            ['employee_id' => $request->employee_id, 'date' => $today],
            [
                'status' => $request->status,
                'clock_in' => $request->clock_in ?: Carbon::now()->toTimeString(),
                'clock_out' => $request->clock_out ?: null,
            ]
        );

        return redirect()->back()->with('success', 'Attendance marked successfully.');
    }

    public function approveLeave($id)
    {
        $leave = HrmLeave::findOrFail($id);
        $leave->update(['status' => 'approved']);
        return redirect()->back()->with('success', 'Leave request approved.');
    }

    public function rejectLeave($id)
    {
        $leave = HrmLeave::findOrFail($id);
        $leave->update(['status' => 'rejected']);
        return redirect()->back()->with('success', 'Leave request rejected.');
    }

    public function processPayroll(Request $request)
    {
        $request->validate([
            'employee_id' => 'required|exists:hrm_employees,id',
            'month' => 'required|string',
            'bonus' => 'required|numeric|min:0',
            'deductions' => 'required|numeric|min:0',
        ]);

        $employee = HrmEmployee::findOrFail($request->employee_id);
        $netPay = $employee->salary + $request->bonus - $request->deductions;

        HrmPayroll::updateOrCreate(
            ['employee_id' => $request->employee_id, 'month' => $request->month],
            [
                'base_salary' => $employee->salary,
                'bonus' => $request->bonus,
                'deductions' => $request->deductions,
                'net_pay' => $netPay,
                'status' => 'paid',
            ]
        );

        return redirect()->back()->with('success', 'Payroll processed successfully.');
    }
}
