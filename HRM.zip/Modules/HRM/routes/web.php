<?php

use Illuminate\Support\Facades\Route;

Route::middleware(['web', 'auth'])->prefix('modules/hrm')->group(function () {
    Route::get('dashboard', 'HrmController@dashboard')->middleware('permission:hrm.dashboard.view');
    Route::get('employees', 'HrmController@employees')->middleware('permission:hrm.employees.view');
    Route::get('attendance', 'HrmController@attendance')->middleware('permission:hrm.attendance.view');
    Route::get('leaves', 'HrmController@leaves')->middleware('permission:hrm.leaves.view');
    Route::get('payroll', 'HrmController@payroll')->middleware('permission:hrm.payroll.view');

    // Action Endpoints
    Route::post('employees', 'HrmController@storeEmployee')->middleware('permission:hrm.employees.create');
    Route::post('attendance', 'HrmController@markAttendance')->middleware('permission:hrm.attendance.create');
    Route::post('leaves/{id}/approve', 'HrmController@approveLeave')->middleware('permission:hrm.leaves.approve');
    Route::post('leaves/{id}/reject', 'HrmController@rejectLeave')->middleware('permission:hrm.leaves.approve');
    Route::post('payroll', 'HrmController@processPayroll')->middleware('permission:hrm.payroll.create');
});
