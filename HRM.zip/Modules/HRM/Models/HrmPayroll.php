<?php

namespace Modules\HRM\Models;

use Illuminate\Database\Eloquent\Model;

class HrmPayroll extends Model
{
    protected $table = 'hrm_payrolls';
    protected $fillable = [
        'employee_id',
        'month',
        'base_salary',
        'bonus',
        'deductions',
        'net_pay',
        'status',
    ];

    public function employee()
    {
        return $this->belongsTo(HrmEmployee::class, 'employee_id');
    }
}
