<?php

namespace Modules\HRM\Models;

use Illuminate\Database\Eloquent\Model;

class HrmDesignation extends Model
{
    protected $table = 'hrm_designations';
    protected $fillable = ['name', 'description'];

    public function employees()
    {
        return $this->hasMany(HrmEmployee::class, 'designation_id');
    }
}
