<?php

namespace Modules\HRM\Models;

use Illuminate\Database\Eloquent\Model;

class HrmAttendance extends Model
{
    protected $table = 'hrm_attendances';
    protected $fillable = [
        'employee_id',
        'date',
        'clock_in',
        'clock_out',
        'status',
    ];

    public function employee()
    {
        return $this->belongsTo(HrmEmployee::class, 'employee_id');
    }
}
