<?php

namespace Modules\HRM\Models;

use Illuminate\Database\Eloquent\Model;

class HrmDepartment extends Model
{
    protected $table = 'hrm_departments';
    protected $fillable = ['name', 'description'];

    public function employees()
    {
        return $this->hasMany(HrmEmployee::class, 'department_id');
    }
}
