<?php

namespace Modules\HRM\Models;

use Illuminate\Database\Eloquent\Model;

class HrmLeave extends Model
{
    protected $table = 'hrm_leaves';
    protected $fillable = [
        'employee_id',
        'type',
        'start_date',
        'end_date',
        'reason',
        'status',
    ];

    public function employee()
    {
        return $this->belongsTo(HrmEmployee::class, 'employee_id');
    }
}
