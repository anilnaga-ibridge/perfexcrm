<?php

namespace Modules\HRM\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\User;

class HrmEmployee extends Model
{
    protected $table = 'hrm_employees';
    protected $fillable = [
        'user_id',
        'department_id',
        'designation_id',
        'employee_id',
        'joining_date',
        'salary',
        'status',
    ];

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function department()
    {
        return $this->belongsTo(HrmDepartment::class, 'department_id');
    }

    public function designation()
    {
        return $this->belongsTo(HrmDesignation::class, 'designation_id');
    }

    public function attendances()
    {
        return $this->hasMany(HrmAttendance::class, 'employee_id');
    }

    public function leaves()
    {
        return $this->hasMany(HrmLeave::class, 'employee_id');
    }

    public function payrolls()
    {
        return $this->hasMany(HrmPayroll::class, 'employee_id');
    }
}
